import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const primary = Color(0xFF4F46E5);

  static const success = Color(0xFF16A34A);

  static const warning = Color(0xFFF59E0B);

  static const error = Color(0xFFDC2626);

  static const background = Color(0xFFF8FAFC);

  static const card = Colors.white;

  static const textPrimary = Color(0xFF111827);

  static const textSecondary = Color(0xFF6B7280);

  static const border = Color(0xFFE5E7EB);
}